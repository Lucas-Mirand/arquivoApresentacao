'use strict';

/* ── Firebase Config ── */
firebase.initializeApp({
    apiKey: "AIzaSyBxHk2vUHjuEkEukOGjhBAghEOXaSTlrKU",
    authDomain: "ecobin-9745c.firebaseapp.com",
    projectId: "ecobin-9745c",
    storageBucket: "ecobin-9745c.firebasestorage.app",
    messagingSenderId: "949198108086",
    appId: "1:949198108086:web:673d5314b28e19f5b73d17"
});

const auth = firebase.auth();
const db = firebase.firestore();
db.enablePersistence({ synchronizeTabs: true }).catch(() => {});

const GEMINI_API_KEY = 'AIzaSyCPQyGqyChQdX-mPw0vsJHTa8wRFS6-f9o';
const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
const BASE_COORDS = { x: 50, y: 50 };
const CRITICAL_THRESHOLD = 70;

/* ── State ── */
let currentUser = null;
let userData = null;
let binsData = [];
let driversData = [];
let isDarkMode = true;
let activeView = 'map';
let selectedBinId = null;
let mobileChatUnsub = null;
let mobileChatRoomId = null;

/* ── DOM refs ── */
const el = id => document.getElementById(id);

/* ── Auth ── */
auth.onAuthStateChanged(async user => {
    if (user) {
        currentUser = user;
        const doc = await db.collection('users').doc(user.uid).get();
        userData = doc.exists ? doc.data() : { displayName: user.email, role: 'driver' };
        el('login-screen').hidden = true;
        el('app-shell').hidden = false;
        el('js-header-subtitle').textContent = `Operador: ${userData.displayName || 'Motorista'}`;
        updateProfile();
        startListeners();
        lucide.createIcons();
    } else {
        currentUser = null;
        userData = null;
        el('login-screen').hidden = false;
        el('app-shell').hidden = true;
    }
});

el('login-form').addEventListener('submit', async e => {
    e.preventDefault();
    const email = el('login-email').value;
    const pass = el('login-password').value;
    const btn = el('login-btn');
    const err = el('login-error');
    btn.disabled = true;
    el('login-btn-text').textContent = 'Entrando...';
    err.hidden = true;
    try {
        await auth.signInWithEmailAndPassword(email, pass);
    } catch (error) {
        err.textContent = 'E-mail ou senha incorretos.';
        err.hidden = false;
    } finally {
        btn.disabled = false;
        el('login-btn-text').textContent = 'Entrar';
    }
});

function handleLogout() {
    if (confirm('Deseja sair?')) auth.signOut();
}

/* ── Profile ── */
function updateProfile() {
    if (!userData) return;
    el('profile-name').textContent = userData.displayName || '-';
    el('profile-role').textContent = userData.role === 'admin' ? 'Administrador' : 'Motorista';
    el('profile-email').textContent = userData.email || currentUser.email;
    el('profile-age').textContent = userData.age ? `${userData.age} anos` : '-';
    el('profile-id').textContent = userData.employeeId || '-';
    el('profile-phone').textContent = userData.phone || '-';
    el('profile-avatar').textContent = userData.avatar || '👤';

    // Gamification
    const gam = userData.gamification || {};
    el('gamification-level').textContent = `Nível ${gam.level || 0}`;
    el('gamification-stats').textContent = `${gam.monthlyCollections || 0} coletas este mês`;
    const progress = Math.min(100, ((gam.monthlyCollections || 0) / 20) * 100);
    el('gamification-progress-bar').style.width = `${progress}%`;
}

/* ── Firestore Listeners ── */
function startListeners() {
    // Bins
    db.collection('bins').onSnapshot(snap => {
        binsData = [];
        snap.forEach(doc => binsData.push({ id: doc.id, ...doc.data() }));
        if (activeView === 'map') renderMap();
        renderQueue();
        // Update selected bin modal if open
        if (selectedBinId) {
            const bin = binsData.find(b => b.id === selectedBinId);
            if (bin) updateBinModal(bin);
        }
    });

    // Drivers
    db.collection('users').where('role', '==', 'driver').onSnapshot(snap => {
        driversData = [];
        snap.forEach(doc => driversData.push({ id: doc.id, ...doc.data() }));
        renderQueue();
    });

    // My collections (history)
    if (currentUser) {
        db.collection('collections')
            .where('driverId', '==', currentUser.uid)
            .orderBy('collectedAt', 'desc')
            .limit(20)
            .onSnapshot(snap => {
                const collections = [];
                snap.forEach(doc => collections.push(doc.data()));
                renderHistory(collections);
            });
    }
}

/* ── Map Rendering (Smart City) ── */
function createSvg(tag) {
    return document.createElementNS('http://www.w3.org/2000/svg', tag);
}
function setA(el, attrs) {
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
}

function renderMap() {
    const svg = el('js-svg-map');
    if (!svg) return;
    svg.innerHTML = '';

    const streets = RouteEngine.STREETS;
    const buildings = RouteEngine.BUILDINGS;
    const roadColor = isDarkMode ? '#1A2A3A' : '#D1D5DB';
    const sideWalk = isDarkMode ? '#111F2E' : '#E5E7EB';
    const markingColor = isDarkMode ? 'rgba(255,220,100,0.12)' : 'rgba(200,180,50,0.2)';

    // Defs
    const defs = createSvg('defs');
    defs.innerHTML = '<filter id="glow-r" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter><filter id="shd" x="-10%" y="-10%" width="120%" height="120%"><feDropShadow dx="0.3" dy="0.3" stdDeviation="0.3" flood-opacity="0.2"/></filter>';
    svg.appendChild(defs);

    // Streets
    streets.horizontal.forEach(s => {
        const sw = createSvg('rect');
        setA(sw, { x: s.x1, y: s.y - s.w/2 - 0.4, width: s.x2 - s.x1, height: s.w + 0.8, fill: sideWalk, rx: 0.3 });
        svg.appendChild(sw);
        const rd = createSvg('rect');
        setA(rd, { x: s.x1, y: s.y - s.w/2, width: s.x2 - s.x1, height: s.w, fill: roadColor, rx: 0.2 });
        svg.appendChild(rd);
        if (s.main) {
            const ln = createSvg('line');
            setA(ln, { x1: s.x1+2, y1: s.y, x2: s.x2-2, y2: s.y, stroke: markingColor, 'stroke-width': 0.15, 'stroke-dasharray': '2,1.5' });
            svg.appendChild(ln);
        }
    });
    streets.vertical.forEach(s => {
        const sw = createSvg('rect');
        setA(sw, { x: s.x - s.w/2 - 0.4, y: s.y1, width: s.w + 0.8, height: s.y2 - s.y1, fill: sideWalk, rx: 0.3 });
        svg.appendChild(sw);
        const rd = createSvg('rect');
        setA(rd, { x: s.x - s.w/2, y: s.y1, width: s.w, height: s.y2 - s.y1, fill: roadColor, rx: 0.2 });
        svg.appendChild(rd);
        if (s.main) {
            const ln = createSvg('line');
            setA(ln, { x1: s.x, y1: s.y1+2, x2: s.x, y2: s.y2-2, stroke: markingColor, 'stroke-width': 0.15, 'stroke-dasharray': '2,1.5' });
            svg.appendChild(ln);
        }
    });

    // Intersections
    streets.horizontal.forEach(h => {
        streets.vertical.forEach(v => {
            if (v.x >= h.x1 && v.x <= h.x2 && h.y >= v.y1 && h.y <= v.y2) {
                const ix = createSvg('rect');
                const hw = Math.max(h.w, v.w);
                setA(ix, { x: v.x - hw/2, y: h.y - hw/2, width: hw, height: hw, fill: roadColor, rx: 0.1 });
                svg.appendChild(ix);
            }
        });
    });

    // Buildings
    buildings.forEach(b => {
        const rect = createSvg('rect');
        setA(rect, { x: b.x, y: b.y, width: b.w, height: b.h, fill: RouteEngine.getBuildingColor(b.type, isDarkMode), stroke: RouteEngine.getBuildingStroke(b.type, isDarkMode), 'stroke-width': 0.15, rx: b.type === 'park' ? 0.8 : 0.3, filter: 'url(#shd)' });
        svg.appendChild(rect);
        if (b.type !== 'park' && b.w >= 4 && b.h >= 4) {
            const wc = isDarkMode ? 'rgba(107,197,247,0.08)' : 'rgba(28,61,90,0.06)';
            for (let wx = b.x+0.8; wx < b.x+b.w-0.5; wx += 1.2)
                for (let wy = b.y+0.8; wy < b.y+b.h-0.5; wy += 1.2) {
                    const w = createSvg('rect');
                    setA(w, { x: wx, y: wy, width: 0.6, height: 0.6, fill: wc, rx: 0.1 });
                    svg.appendChild(w);
                }
        }
        if (b.type === 'park') {
            for (let i = 0; i < 3; i++) {
                const tr = createSvg('circle');
                setA(tr, { cx: b.x + b.w*(0.25+i*0.25), cy: b.y + b.h*0.5, r: 0.8, fill: isDarkMode ? 'rgba(140,231,141,0.15)' : 'rgba(91,191,94,0.25)' });
                svg.appendChild(tr);
            }
        }
    });

    // Active routes (A* pathfinding)
    driversData.forEach((driver, i) => {
        if (driver.status !== 'on_route' || !driver.activeRoute) return;
        const binCoords = driver.activeRoute.map(id => { const b = binsData.find(x => x.id === id); return b ? b.coords : null; }).filter(Boolean);
        if (!binCoords.length) return;
        const colors = ['#8CE78D', '#6BC5F7', '#FFD93D'];
        const color = colors[i % colors.length];
        const wp = RouteEngine.buildRoutePath(BASE_COORDS, binCoords);
        const d = RouteEngine.waypointsToSvgPath(wp);
        if (!d) return;
        const glow = createSvg('path');
        setA(glow, { d, fill: 'none', stroke: color, 'stroke-width': 1.8, opacity: 0.15, filter: 'url(#glow-r)', 'stroke-linejoin': 'round' });
        svg.appendChild(glow);
        const path = createSvg('path');
        setA(path, { d, fill: 'none', stroke: color, 'stroke-width': 0.7, opacity: 0.9, 'stroke-dasharray': '2,1', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' });
        const an = createSvg('animate');
        setA(an, { attributeName: 'stroke-dashoffset', from: '0', to: '-30', dur: '3s', repeatCount: 'indefinite' });
        path.appendChild(an);
        svg.appendChild(path);
    });

    // Base
    const baseG = createSvg('g');
    const bglow = createSvg('circle');
    setA(bglow, { cx: BASE_COORDS.x, cy: BASE_COORDS.y, r: 3.5, fill: 'rgba(140,231,141,0.08)' });
    baseG.appendChild(bglow);
    const brect = createSvg('rect');
    setA(brect, { x: BASE_COORDS.x-2, y: BASE_COORDS.y-2, width: 4, height: 4, fill: isDarkMode ? '#1A3D2A' : '#D4EDDA', stroke: '#8CE78D', 'stroke-width': 0.3, rx: 0.5 });
    baseG.appendChild(brect);
    const bicon = createSvg('text');
    setA(bicon, { x: BASE_COORDS.x, y: BASE_COORDS.y+1, 'text-anchor': 'middle', 'font-size': 3 });
    bicon.textContent = '🏭';
    baseG.appendChild(bicon);
    const blbl = createSvg('text');
    setA(blbl, { x: BASE_COORDS.x, y: BASE_COORDS.y-3.5, 'text-anchor': 'middle', 'font-size': 1.8, fill: '#8CE78D', 'font-weight': '900' });
    blbl.textContent = 'BASE';
    baseG.appendChild(blbl);
    svg.appendChild(baseG);

    // Bins
    binsData.forEach(bin => {
        if (!bin.coords) return;
        const cx = bin.coords.x, cy = bin.coords.y;
        const color = RouteEngine.getBinColor(bin.fillLevel);
        const isCritical = bin.fillLevel >= CRITICAL_THRESHOLD;
        const g = createSvg('g');
        g.style.cursor = 'pointer';
        g.addEventListener('click', () => openBinModal(bin.id));

        if (isCritical) {
            const gl = createSvg('circle');
            setA(gl, { cx, cy: cy-0.3, r: 4, fill: RouteEngine.getBinGlowColor(bin.fillLevel), class: 'animate-pulse' });
            g.appendChild(gl);
        }
        // Bin body
        const body = createSvg('rect');
        setA(body, { x: cx-1.3, y: cy-1, width: 2.6, height: 2.8, fill: isDarkMode ? '#1A2A3A' : '#D8DEE4', stroke: color, 'stroke-width': 0.25, rx: 0.3 });
        g.appendChild(body);
        // Fill level
        const fh = (2.8 * bin.fillLevel) / 100;
        const fr = createSvg('rect');
        setA(fr, { x: cx-1.15, y: cy-1+(2.8-fh)+0.15, width: 2.3, height: Math.max(0.1, fh-0.15), fill: color, opacity: 0.6, rx: 0.2 });
        g.appendChild(fr);
        // Lid
        const lid = createSvg('rect');
        setA(lid, { x: cx-1.5, y: cy-1.6, width: 3, height: 0.7, fill: color, rx: 0.2 });
        g.appendChild(lid);
        // Handle
        const hdl = createSvg('rect');
        setA(hdl, { x: cx-0.4, y: cy-2, width: 0.8, height: 0.5, fill: color, rx: 0.2 });
        g.appendChild(hdl);
        // Percentage
        const pct = createSvg('text');
        setA(pct, { x: cx, y: cy+0.6, 'text-anchor': 'middle', 'font-size': 1.5, fill: '#fff', 'font-weight': '900' });
        pct.textContent = Math.round(bin.fillLevel) + '%';
        g.appendChild(pct);
        // Name
        const nm = createSvg('text');
        setA(nm, { x: cx, y: cy-3.2, 'text-anchor': 'middle', 'font-size': 1.6, fill: isDarkMode ? 'rgba(255,255,255,0.5)' : 'rgba(28,61,90,0.6)', 'font-weight': '700' });
        nm.textContent = bin.name.replace('PEV ', '');
        g.appendChild(nm);
        svg.appendChild(g);
    });

    // Trucks
    driversData.forEach(driver => {
        if (!driver.currentPosition) return;
        const px = driver.currentPosition.x, py = driver.currentPosition.y;
        const sc = { on_route: '#8CE78D', collecting: '#6BC5F7', returning: '#FFD93D', online: '#94A3B8' };
        const color = sc[driver.status] || '#94A3B8';
        const g = createSvg('g');
        setA(g, { transform: `translate(${px}, ${py})` });
        const truck = createSvg('rect');
        setA(truck, { x: -2, y: -1.2, width: 4, height: 2.4, fill: color, rx: 0.4, stroke: 'rgba(255,255,255,0.2)', 'stroke-width': 0.15 });
        g.appendChild(truck);
        const cab = createSvg('rect');
        setA(cab, { x: 1.2, y: -0.8, width: 1.2, height: 1.6, fill: 'rgba(255,255,255,0.15)', rx: 0.2 });
        g.appendChild(cab);
        const nl = createSvg('text');
        setA(nl, { x: 0, y: -2.5, 'text-anchor': 'middle', 'font-size': 1.4, fill: color, 'font-weight': '800' });
        nl.textContent = (driver.displayName || '').split(' ')[0];
        g.appendChild(nl);
        svg.appendChild(g);
    });
}

/* ── Bin Modal ── */
function openBinModal(binId) {
    const bin = binsData.find(b => b.id === binId);
    if (!bin) return;
    selectedBinId = binId;
    updateBinModal(bin);
    el('js-pev-modal').hidden = false;
    lucide.createIcons();
}

function updateBinModal(bin) {
    el('js-pev-modal-title').textContent = bin.name;
    el('js-pev-modal-location').textContent = bin.address || bin.neighborhood || '';
    el('js-pev-modal-level-text').textContent = `${Math.round(bin.fillLevel)}%`;
    el('js-pev-modal-progress').style.width = `${bin.fillLevel}%`;

    const isCritical = bin.fillLevel >= CRITICAL_THRESHOLD;
    const actions = el('js-pev-actions');
    if (isCritical) {
        actions.innerHTML = `
            <button onclick="collectBin('${bin.id}')" class="btn-collect">
                <span>🚛 Realizar Coleta</span>
            </button>
        `;
    } else {
        actions.innerHTML = `<div class="pev-action-status pev-action-status--stable">Nível estável — coleta não necessária</div>`;
    }
}

function closeBinModal() {
    el('js-pev-modal').hidden = true;
    selectedBinId = null;
}

/* ── Collection ── */
async function collectBin(binId) {
    const bin = binsData.find(b => b.id === binId);
    if (!bin) return;

    showNotification(`Coletando ${bin.name}...`);

    // Create collection record
    await db.collection('collections').add({
        binId: bin.id,
        binName: bin.name,
        driverId: currentUser.uid,
        driverName: userData.displayName,
        truckId: userData.assignedTruckId || 'N/A',
        routeId: '',
        fillLevelBefore: Math.round(bin.fillLevel),
        fillLevelAfter: 0,
        collectedAt: firebase.firestore.FieldValue.serverTimestamp(),
        location: bin.location || null
    });

    // Reset bin level
    await db.collection('bins').doc(binId).update({
        fillLevel: 0,
        status: 'normal',
        lastCollected: firebase.firestore.FieldValue.serverTimestamp()
    });

    // Update gamification
    const gam = userData.gamification || {};
    await db.collection('users').doc(currentUser.uid).update({
        'gamification.totalCollections': (gam.totalCollections || 0) + 1,
        'gamification.monthlyCollections': (gam.monthlyCollections || 0) + 1
    });

    closeBinModal();
    showNotification(`✅ ${bin.name} coletada com sucesso!`);

    // Check for sustainable route suggestion
    setTimeout(() => checkRouteSuggestion(bin), 1500);
}

/* ── Route Suggestion System ── */
function checkRouteSuggestion(collectedBin) {
    const nearbyBins = RouteEngine.findNearbySuggestions(collectedBin, binsData, 25);
    if (nearbyBins.length > 0) {
        showNearbyBinSuggestion(nearbyBins[0], collectedBin);
    } else {
        showSustainableRouteSuggestion();
    }
}

function showNearbyBinSuggestion(nearbyBin, fromBin) {
    const modal = el('route-suggestion-modal');
    if (!modal) return;
    const dist = Math.round(RouteEngine.dist(fromBin.coords, nearbyBin.coords) * 10);
    el('route-suggestion-content').innerHTML = `
        <div style="text-align:center;margin-bottom:1rem">
            <span style="font-size:2.5rem">📍</span>
            <h3 style="font-size:.9rem;font-weight:900;margin:.5rem 0 .25rem">Coleta Próxima Detectada</h3>
            <p style="font-size:.7rem;opacity:.5">A IA encontrou outra lixeira no caminho</p>
        </div>
        <div style="padding:.75rem;background:var(--color-bg-muted);border-radius:var(--radius-md);border:1px solid var(--color-border);margin-bottom:1rem">
            <p style="font-size:.75rem;font-weight:800;margin:0">${nearbyBin.name}</p>
            <p style="font-size:.65rem;opacity:.5;margin:.25rem 0 0">${Math.round(nearbyBin.fillLevel)}% cheio · ~${dist}m do trajeto</p>
        </div>
        <p style="font-size:.7rem;opacity:.6;text-align:center;margin-bottom:1rem">Deseja incluí-la na sua rota para otimizar a coleta?</p>
        <div style="display:flex;gap:.5rem">
            <button onclick="rejectRouteSuggestion()" class="sos-btn sos-btn--cancel" style="flex:1">Pular</button>
            <button onclick="acceptRouteSuggestion('${nearbyBin.id}')" class="btn-collect" style="flex:1;font-size:.75rem">Incluir na Rota</button>
        </div>
    `;
    modal.hidden = false;
}

function showSustainableRouteSuggestion() {
    const criticalBins = binsData.filter(b => b.fillLevel >= 60);
    if (criticalBins.length < 2) return;
    const modal = el('route-suggestion-modal');
    if (!modal) return;
    el('route-suggestion-content').innerHTML = `
        <div style="text-align:center;margin-bottom:1rem">
            <span style="font-size:2.5rem">🌱</span>
            <h3 style="font-size:.9rem;font-weight:900;margin:.5rem 0 .25rem">Rota Sustentável Disponível</h3>
            <p style="font-size:.7rem;opacity:.5">Encontramos um caminho mais eficiente</p>
        </div>
        <div style="display:flex;gap:.75rem;margin-bottom:1rem">
            <div style="flex:1;padding:.6rem;background:var(--color-accent-subtle);border:1px solid var(--color-accent-border);border-radius:var(--radius-sm);text-align:center">
                <p style="font-size:1rem;font-weight:900;color:var(--color-accent);margin:0">-15%</p>
                <p style="font-size:.55rem;opacity:.5;margin:0">Combustível</p>
            </div>
            <div style="flex:1;padding:.6rem;background:var(--color-accent-subtle);border:1px solid var(--color-accent-border);border-radius:var(--radius-sm);text-align:center">
                <p style="font-size:1rem;font-weight:900;color:var(--color-accent);margin:0">-2.3kg</p>
                <p style="font-size:.55rem;opacity:.5;margin:0">CO₂</p>
            </div>
        </div>
        <p style="font-size:.7rem;opacity:.6;text-align:center;margin-bottom:1rem">Deseja seguir esta nova rota?</p>
        <div style="display:flex;gap:.5rem">
            <button onclick="rejectRouteSuggestion()" class="sos-btn sos-btn--cancel" style="flex:1">Manter Atual</button>
            <button onclick="acceptSustainableRoute()" class="btn-collect" style="flex:1;font-size:.75rem">Aceitar Rota</button>
        </div>
    `;
    modal.hidden = false;
}

function acceptRouteSuggestion(binId) {
    el('route-suggestion-modal').hidden = true;
    showNotification('✅ Ponto adicionado à rota!');
    // Sync to Firestore so web dashboard sees the change
    if (currentUser) {
        db.collection('users').doc(currentUser.uid).update({
            status: 'on_route',
            activeRoute: firebase.firestore.FieldValue.arrayUnion(binId)
        });
        db.collection('route_events').add({
            type: 'nearby_accepted', driverId: currentUser.uid,
            driverName: userData.displayName, binId,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
    }
}

function acceptSustainableRoute() {
    el('route-suggestion-modal').hidden = true;
    showNotification('🌱 Rota sustentável aceita!');
    const criticalBins = binsData.filter(b => b.fillLevel >= 60);
    const route = RouteEngine.calculateOptimalRoute(BASE_COORDS, criticalBins);
    if (currentUser) {
        db.collection('users').doc(currentUser.uid).update({
            status: 'on_route',
            activeRoute: route.map(b => b.id)
        });
        db.collection('route_events').add({
            type: 'sustainable_accepted', driverId: currentUser.uid,
            driverName: userData.displayName, routeLength: route.length,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
    }
    renderMap();
}

function rejectRouteSuggestion() {
    el('route-suggestion-modal').hidden = true;
    if (currentUser) {
        db.collection('route_events').add({
            type: 'suggestion_rejected', driverId: currentUser.uid,
            driverName: userData.displayName,
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
    }
}

/* ── Queue ── */
function renderQueue() {
    const list = el('js-queue-list');
    if (!list) return;

    const online = driversData.filter(d => d.status === 'online');
    const onRoute = driversData.filter(d => d.status === 'on_route');

    let html = online.map((d, i) => {
        const isMe = d.id === currentUser?.uid;
        return `
            <div class="queue-item ${isMe ? 'queue-item--user' : ''}">
                <div class="queue-item__inner">
                    <div class="queue-item__badge ${isMe ? 'queue-item__badge--user' : ''}">${i + 1}º</div>
                    <div>
                        <p class="queue-item__name">${d.displayName?.split(' ')[0]}${isMe ? ' (Você)' : ''}</p>
                        <span class="queue-item__status">Online</span>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    html += onRoute.map(d => `
        <div class="queue-item queue-item--in-route">
            <div class="queue-item__inner">
                <div class="queue-item__badge queue-item__badge--route">EM</div>
                <div>
                    <p class="queue-item__name">${d.displayName?.split(' ')[0]}</p>
                    <span class="queue-item__status queue-item__status--route">Em Rota</span>
                </div>
            </div>
        </div>
    `).join('');

    list.innerHTML = html || '<p class="history-empty">Nenhum motorista ativo</p>';
}

/* ── History ── */
function renderHistory(collections) {
    const list = el('js-history-list');
    if (!list) return;

    if (!collections.length) {
        list.innerHTML = '<p class="history-empty">Nenhuma coleta registrada</p>';
        return;
    }

    list.innerHTML = collections.map(c => {
        const time = c.collectedAt?.toDate ? c.collectedAt.toDate().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '--:--';
        return `
            <div class="history-item">
                <div class="history-item__inner">
                    <div class="history-item__icon-wrap">
                        <i data-lucide="check-circle" class="history-item__icon"></i>
                    </div>
                    <div>
                        <h4 class="history-item__label">Coleta Concluída</h4>
                        <p class="history-item__detail">Local: ${c.binName}</p>
                    </div>
                </div>
                <span class="history-item__time">${time}</span>
            </div>
        `;
    }).join('');
    lucide.createIcons();
}

/* ── SOS ── */
el('js-btn-sos').addEventListener('click', () => { el('sos-modal').hidden = false; });
function closeSosModal() { el('sos-modal').hidden = true; }

async function submitSos() {
    const type = el('sos-type').value;
    const desc = el('sos-description').value;

    await db.collection('incidents').add({
        type,
        description: desc,
        reportedBy: currentUser.uid,
        binId: null,
        location: null,
        photos: [],
        status: 'open',
        priority: type === 'sos' ? 'critical' : 'medium',
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });

    closeSosModal();
    el('sos-description').value = '';
    showNotification('🚨 Ocorrência reportada com sucesso!');
}

/* ── Chat ── */
function openSupportChat() {
    switchView('chat');

    // Find admin chat room
    db.collection('chat').where('participants', 'array-contains', currentUser.uid).get().then(snap => {
        let roomId = null;
        snap.forEach(doc => {
            const data = doc.data();
            if (data.participantNames && data.participantNames.some(n => n.includes('Admin'))) {
                roomId = doc.id;
            }
        });

        if (!roomId) {
            roomId = `chat-mobile-${currentUser.uid}`;
            db.collection('chat').doc(roomId).set({
                participants: [currentUser.uid],
                participantNames: [userData.displayName],
                lastMessage: '',
                lastMessageAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }

        mobileChatRoomId = roomId;
        listenMobileChat(roomId);
    });
}

function listenMobileChat(roomId) {
    if (mobileChatUnsub) mobileChatUnsub();
    const msgs = el('mobile-chat-messages');

    mobileChatUnsub = db.collection('chat').doc(roomId).collection('messages')
        .orderBy('createdAt', 'asc')
        .onSnapshot(snap => {
            msgs.innerHTML = '';
            snap.forEach(doc => {
                const m = doc.data();
                let cls = m.senderId === currentUser.uid ? 'mobile-msg--sent' : 'mobile-msg--received';
                if (m.type === 'system') cls = 'mobile-msg--system';
                if (m.type === 'ai_response') cls = 'mobile-msg--ai';
                msgs.innerHTML += `<div class="${cls}">${m.text}</div>`;
            });
            msgs.scrollTop = msgs.scrollHeight;
        });
}

async function sendMobileChat() {
    const input = el('mobile-chat-input');
    const text = input.value.trim();
    if (!text || !mobileChatRoomId) return;
    input.value = '';

    await db.collection('chat').doc(mobileChatRoomId).collection('messages').add({
        senderId: currentUser.uid,
        senderName: userData.displayName,
        text,
        type: 'text',
        readBy: [currentUser.uid],
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
}

/* ── Navigation ── */
function switchView(viewName) {
    activeView = viewName;
    document.querySelectorAll('.app-view').forEach(v => v.hidden = true);
    const target = el(`view-${viewName}`);
    if (target) target.hidden = false;

    document.querySelectorAll('.nav-tab').forEach(t => {
        t.classList.remove('nav-tab--active');
        t.removeAttribute('aria-current');
    });
    const tab = el(`nav-${viewName}`);
    if (tab) { tab.classList.add('nav-tab--active'); tab.setAttribute('aria-current', 'page'); }

    if (viewName === 'map') renderMap();
    if (viewName === 'history') lucide.createIcons();
    lucide.createIcons();
}

/* ── Theme ── */
function toggleTheme() {
    isDarkMode = !isDarkMode;
    document.body.className = isDarkMode ? 'theme--dark' : 'theme--light';
    const icon = el('js-theme-icon');
    if (icon) { icon.setAttribute('data-lucide', isDarkMode ? 'sun' : 'moon'); lucide.createIcons(); }
    renderMap();
}

/* ── Notifications ── */
function showNotification(msg) {
    const n = el('js-notification');
    el('js-notification-text').textContent = msg;
    n.hidden = false;
    setTimeout(() => { n.hidden = true; }, 3000);
}

/* ── Init ── */
window.addEventListener('DOMContentLoaded', () => {
    // Nav tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            const view = tab.dataset.view;
            if (view) switchView(view);
        });
    });

    // Close bin modal
    el('js-close-pev-modal').addEventListener('click', closeBinModal);
    el('js-theme-toggle').addEventListener('click', toggleTheme);
    el('js-btn-support').addEventListener('click', openSupportChat);

    lucide.createIcons();
});